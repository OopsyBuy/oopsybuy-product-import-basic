<?php
// includes/file-import.php

use PhpOffice\PhpSpreadsheet\IOFactory;

if (isset($_POST['import_file'])) {
    if (isset($_FILES['product_file']) && $_FILES['product_file']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['product_file']['tmp_name'];
        $file_ext = strtolower(pathinfo($_FILES['product_file']['name'], PATHINFO_EXTENSION));

        try {
            if ($file_ext === 'csv') {
                // Handle CSV import
                $rows = array_map('str_getcsv', file($file_tmp));

                // Process the data (skip the header row)
                if (count($rows) > 1) {
                    for ($i = 1; $i < count($rows); $i++) {
                        $row = $rows[$i];

                        // Assuming columns are: Product Name, Product URL, Original Price, Final Price
                        $product_name = isset($row[0]) ? sanitize_text_field($row[0]) : '';
                        $product_url = isset($row[1]) ? esc_url_raw($row[1]) : '';
                        $original_price = isset($row[2]) ? floatval($row[2]) : 0.00;
                        $final_price = isset($row[3]) ? floatval($row[3]) : 0.00;

                        // Import product (replace with your WooCommerce import logic)
                        // ... (WooCommerce product creation) ...
                        // Log the import
                        oopsybuy_basic_log_imported_product($product_name, $product_url, 'File Upload', 'CSV Import', $original_price, $final_price);
                    }
                    echo '<div class="notice notice-success is-dismissible"><p>CSV file imported successfully.</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>No data found in the CSV file.</p></div>';
                }
            } else {
                // Handle Excel import
                $spreadsheet = IOFactory::load($file_tmp);
                $worksheet = $spreadsheet->getActiveSheet();
                $rows = $worksheet->toArray();

                // Process the data (skip the header row)
                if (count($rows) > 1) {
                    for ($i = 1; $i < count($rows); $i++) {
                        $row = $rows[$i];

                        // Assuming columns are: Product Name, Product URL, Original Price, Final Price
                        $product_name = isset($row[0]) ? sanitize_text_field($row[0]) : '';
                        $product_url = isset($row[1]) ? esc_url_raw($row[1]) : '';
                        $original_price = isset($row[2]) ? floatval($row[2]) : 0.00;
                        $final_price = isset($row[3]) ? floatval($row[3]) : 0.00;

                        // Import product (replace with your WooCommerce import logic)
                        // ... (WooCommerce product creation) ...
                        // Log the import
                        oopsybuy_basic_log_imported_product($product_name, $product_url, 'File Upload', 'Excel Import', $original_price, $final_price);
                    }
                    echo '<div class="notice notice-success is-dismissible"><p>Excel file imported successfully.</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>No data found in the Excel file.</p></div>';
                }
            }
        } catch (\PhpOffice\PhpSpreadsheet\Reader\Exception $e) {
            echo '<div class="notice notice-error is-dismissible"><p>Error reading file: ' . esc_html($e->getMessage()) . '</p></div>';
        }
    } else {
        echo '<div class="notice notice-error is-dismissible"><p>Please select a file to import.</p></div>';
    }
}
?>

<div class="wrap">
    <h2>File Import</h2>

    <form method="post" enctype="multipart/form-data">
        <label for="product_file">Select Excel or CSV File:</label>
        <input type="file" name="product_file" id="product_file" accept=".xls,.xlsx,.csv">
        <input type="submit" name="import_file" class="button button-primary" value="Import">
    </form>
</div>