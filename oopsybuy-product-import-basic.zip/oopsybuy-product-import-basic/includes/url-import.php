<?php
// includes/url-import.php

use Goutte\Client;

if (isset($_POST['import_url'])) {
    $product_url = esc_url_raw($_POST['product_url']);

    if (!empty($product_url)) {
        $parsed_url = parse_url($product_url);
        $allowed_domains = [
            'aliexpress.com',
            'www.aliexpress.com',
            'm.aliexpress.com',
            'walmart.com',
            'www.walmart.com',
            'amazon.com',
            'www.amazon.com',
            'alibaba.com',
            'www.alibaba.com',
            'cjdropshipping.com',
            'www.cjdropshipping.com',
            'doba.com',
            'www.doba.com',
        ];

        if (isset($parsed_url['host']) && in_array($parsed_url['host'], $allowed_domains)) {
            $client = new Client();
            try {
                $crawler = $client->request('GET', $product_url);

                // Extract product data (adjust selectors as needed)
                $product_name = $crawler->filter('h1.product-title, .product-title, #productTitle')->text();
                $original_price = $crawler->filter('.product-price, .price, .offer-price')->text(); // Adjust selector
                //Add more selectors as needed.

                // Sanitize and process data
                $product_name = sanitize_text_field($product_name);
                $original_price = preg_replace('/[^0-9.]/', '', $original_price); // Remove non-numeric characters
                $original_price = floatval($original_price);

                // Placeholder for final price calculation (replace with your logic)
                $final_price = $original_price;

                // Placeholder for WooCommerce import logic
                // ... (WooCommerce product creation) ...

                // Log the import
                oopsybuy_basic_log_imported_product($product_name, $product_url, 'URL Import', 'URL Import', $original_price, $final_price);

                echo '<div class="notice notice-success is-dismissible"><p>Product imported from URL successfully.</p></div>';
            } catch (\Exception $e) {
                echo '<div class="notice notice-error is-dismissible"><p>Error importing from URL: ' . esc_html($e->getMessage()) . '</p></div>';
            }
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>Invalid URL. Only URLs from AliExpress, Walmart, Amazon, Alibaba, CJ Imports, and Doba are allowed.</p></div>';
        }
    } else {
        echo '<div class="notice notice-error is-dismissible"><p>Please enter a product URL.</p></div>';
    }
}
?>

<div class="wrap">
    <h2>URL Import</h2>
    <p>Only URLs from the following websites are supported: AliExpress, Walmart, Amazon, Alibaba, CJ Imports, and Doba.</p>

    <form method="post">
        <label for="product_url">Product URL:</label>
        <input type="url" name="product_url" id="product_url" required>
        <input type="submit" name="import_url" class="button button-primary" value="Import">
    </form>
</div>