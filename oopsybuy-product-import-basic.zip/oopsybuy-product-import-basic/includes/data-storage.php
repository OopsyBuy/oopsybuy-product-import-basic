<?php
// includes/data-storage.php

function oopsybuy_product_import_basic_create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // Table for imported products
    $table_name_products = $wpdb->prefix . 'oopsybuy_basic_imported_products';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name_products'") != $table_name_products) {
        $sql_products = "CREATE TABLE $table_name_products (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            product_name varchar(255) NOT NULL,
            product_url text,
            source varchar(50),
            import_type varchar(50),
            import_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            original_price decimal(10, 2),
            final_price decimal(10, 2),
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_products);
    }

    // Table for pricing setups
    $table_name_pricing = $wpdb->prefix . 'oopsybuy_basic_pricing_setups';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name_pricing'") != $table_name_pricing) {
        $sql_pricing = "CREATE TABLE $table_name_pricing (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            pricing_type varchar(50) NOT NULL,
            value decimal(10, 2),
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_pricing);
    }

    // Table for product search history
    $table_name_search_history = $wpdb->prefix . 'oopsybuy_basic_search_history';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name_search_history'") != $table_name_search_history) {
        $sql_search_history = "CREATE TABLE $table_name_search_history (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            search_term varchar(255) NOT NULL,
            search_type varchar(50) NOT NULL,
            search_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_search_history);
    }
}

// Function to log imported product
function oopsybuy_basic_log_imported_product($product_name, $product_url, $source, $import_type, $original_price, $final_price) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'oopsybuy_basic_imported_products';
    $wpdb->insert(
        $table_name,
        array(
            'product_name' => $product_name,
            'product_url' => $product_url,
            'source' => $source,
            'import_type' => $import_type,
            'import_date' => current_time('mysql'),
            'original_price' => $original_price,
            'final_price' => $final_price,
        )
    );
}

// Function to log pricing setup
function oopsybuy_basic_log_pricing_setup($pricing_type, $value) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'oopsybuy_basic_pricing_setups';
    $wpdb->insert(
        $table_name,
        array(
            'pricing_type' => $pricing_type,
            'value' => $value,
        )
    );
}

// Function to log product search
function oopsybuy_basic_log_product_search($search_term, $search_type) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'oopsybuy_basic_search_history';
    $wpdb->insert(
        $table_name,
        array(
            'search_term' => $search_term,
            'search_type' => $search_type,
            'search_date' => current_time('mysql'),
        )
    );
}
?>