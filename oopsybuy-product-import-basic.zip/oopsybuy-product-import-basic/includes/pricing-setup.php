<?php
// includes/pricing-setup.php

if (isset($_POST['save_pricing_setup'])) {
    $pricing_type = sanitize_text_field($_POST['pricing_type']);
    $value = floatval($_POST['value']);

    if (in_array($pricing_type, ['fixed', 'percentage']) && $value >= 0) {
        // Clear existing pricing setups
        global $wpdb;
        $table_name = $wpdb->prefix . 'oopsybuy_basic_pricing_setups';
        $wpdb->query("TRUNCATE TABLE $table_name");

        // Save new pricing setup
        oopsybuy_basic_log_pricing_setup($pricing_type, $value);

        echo '<div class="notice notice-success is-dismissible"><p>Pricing setup saved successfully.</p></div>';
    } else {
        echo '<div class="notice notice-error is-dismissible"><p>Invalid pricing type or value. Value must be a positive number.</p></div>';
    }
}

// Get current pricing setup
global $wpdb;
$table_name = $wpdb->prefix . 'oopsybuy_basic_pricing_setups';
$current_setup = $wpdb->get_row("SELECT * FROM $table_name");

$current_type = '';
$current_value = '';
if ($current_setup) {
    $current_type = $current_setup->pricing_type;
    $current_value = $current_setup->value;
}

?>

<div class="wrap">
    <h2>Pricing Setup</h2>

    <form method="post">
        <label for="pricing_type">Pricing Type:</label>
        <select name="pricing_type" id="pricing_type">
            <option value="fixed" <?php selected($current_type, 'fixed'); ?>>Fixed Markup</option>
            <option value="percentage" <?php selected($current_type, 'percentage'); ?>>Percentage Markup</option>
        </select>

        <label for="value">Value:</label>
        <input type="number" name="value" id="value" step="0.01" value="<?php echo esc_attr($current_value); ?>" required>

        <input type="submit" name="save_pricing_setup" class="button button-primary" value="Save Pricing Setup">
    </form>
</div>