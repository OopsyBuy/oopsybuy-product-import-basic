<?php
// includes/upgrade.php

?>

<div class="wrap">
    <h2>Upgrade to OopsyBuy Pro</h2>

    <p>Unlock advanced features and supercharge your dropshipping business!</p>

    <div class="upgrade-options">
        <div class="upgrade-option blurred">
            <h3>One-Click Import</h3>
            <p>Instantly import products with a single click.</p>
        </div>

        <div class="upgrade-option blurred">
            <h3>Automated Pricing Rules</h3>
            <p>Set up advanced pricing rules and automate your pricing strategy.</p>
        </div>

        <div class="upgrade-option blurred">
            <h3>Advanced Product Search</h3>
            <p>Access advanced search filters and find the perfect products faster.</p>
        </div>

        <div class="upgrade-option blurred">
            <h3>Multiple Marketplace Integration</h3>
            <p>Import products from multiple marketplaces with ease.</p>
        </div>

        <div class="upgrade-option blurred">
            <h3>AI Product Suggestions</h3>
            <p>Recieve AI powered product suggestions.</p>
        </div>
    </div>

    <p class="coming-soon">Coming Soon!</p>
</div>

<style>
    .upgrade-options {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        margin-bottom: 20px;
    }

    .upgrade-option {
        width: 250px;
        border: 1px solid #ccc;
        padding: 20px;
        margin: 10px;
        text-align: center;
    }

    .blurred {
        filter: blur(5px);
        opacity: 0.7;
    }

    .coming-soon {
        text-align: center;
        font-size: 1.5em;
        font-weight: bold;
        color: #888;
    }
</style>