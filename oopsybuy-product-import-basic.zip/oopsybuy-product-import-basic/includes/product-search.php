<?php
// includes/product-search.php
?>

<div class="wrap">
    <h2>Product Search</h2>

    <div class="search-section">
        <input type="text" id="product-search" placeholder="Enter product name, UPC, or drag an image here...">
        <div id="search-suggestions"></div>
        <button id="search-button" class="button button-primary">Search</button>
        <input type="file" id="image-upload" accept="image/*" style="display: none;">
    </div>

    <div id="search-results"></div>
</div>

<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('product-search');
        const searchSuggestions = document.getElementById('search-suggestions');
        const searchResults = document.getElementById('search-results');
        const searchButton = document.getElementById('search-button');
        const imageUpload = document.getElementById('image-upload');

        searchInput.addEventListener('input', function() {
            const searchTerm = searchInput.value;
            if (searchTerm.length >= 3) {
                fetchSearchSuggestions(searchTerm);
            } else {
                searchSuggestions.innerHTML = '';
            }
        });

        searchButton.addEventListener('click', function() {
            const searchTerm = searchInput.value;
            performProductSearch(searchTerm);
        });

        function fetchSearchSuggestions(searchTerm) {
            fetch(ajaxurl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: `action=oopsybuy_get_search_suggestions&searchTerm=${encodeURIComponent(searchTerm)}`
            })
            .then(response => response.json())
            .then(data => {
                displaySearchSuggestions(data);
            });
        }

        function displaySearchSuggestions(suggestions) {
            let suggestionsHtml = '';
            suggestions.forEach(suggestion => {
                suggestionsHtml += `<div class="suggestion-item">${suggestion}</div>`;
            });
            searchSuggestions.innerHTML = suggestionsHtml;

            document.querySelectorAll('.suggestion-item').forEach(item => {
                item.addEventListener('click', function() {
                    searchInput.value = this.textContent;
                    searchSuggestions.innerHTML = '';
                    performProductSearch(searchInput.value);
                });
            });
        }

        function performProductSearch(searchTerm, imageData = null) {
            let formData = new FormData();
            formData.append('action', 'oopsybuy_perform_product_search');
            formData.append('searchTerm', searchTerm);
            if (imageData) {
                formData.append('imageData', imageData);
            }

            fetch(ajaxurl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                displaySearchResults(data);
            });
        }

        function displaySearchResults(results) {
            let resultsHtml = '';
            results.forEach(result => {
                resultsHtml += `
                    <div class="result-item">
                        <h3>${result.title}</h3>
                        <p>Price: ${result.price}</p>
                        <p>Source: ${result.source}</p>
                        <p><a href="${result.link}" target="_blank">View Product</a></p>
                    </div>
                `;
            });
            searchResults.innerHTML = resultsHtml;
        }

        // Drag and drop image handling
        searchInput.addEventListener('dragover', function(e) {
            e.preventDefault();
        });

        searchInput.addEventListener('drop', function(e) {
            e.preventDefault();
            const file = e.dataTransfer.files[0];
            handleImageUpload(file);
        });

        imageUpload.addEventListener('change', function(e) {
            const file = e.target.files[0];
            handleImageUpload(file);
        });

        function handleImageUpload(file) {
            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    performProductSearch('', e.target.result);
                };
                reader.readAsDataURL(file);
            } else {
                alert('Please drop an image file.');
            }
        }

    });
</script>
<style>
    #search-suggestions {
        position: absolute;
        background-color: white;
        border: 1px solid #ccc;
        width: 300px;
        z-index: 1000;
    }

    .suggestion-item {
        padding: 5px;
        cursor: pointer;
    }

    .suggestion-item:hover {
        background-color: #f0f0f0;
    }
</style>