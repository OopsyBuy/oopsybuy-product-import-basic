<?php
// includes/aliexpress-import.php

// Check if settings are being saved
if (isset($_POST['save_aliexpress_settings'])) {
    update_option('oopsybuy_aliexpress_api_key', sanitize_text_field($_POST['aliexpress_api_key']));
    echo '<div class="notice notice-success is-dismissible"><p>AliExpress API settings saved.</p></div>';
}

// Check if import is being performed
if (isset($_POST['import_aliexpress_product'])) {
    $product_id = sanitize_text_field($_POST['aliexpress_product_id']);
    $api_key = get_option('oopsybuy_aliexpress_api_key');

    if (empty($api_key)) {
        echo '<div class="notice notice-error is-dismissible"><p>Please set your AliExpress API key in the settings.</p></div>';
    } else {
        // Implement AliExpress API import logic here
        // ... (API call, data processing, WooCommerce import) ...
        // For now, let's just display a message
        echo '<div class="notice notice-success is-dismissible"><p>Product ID: ' . esc_html($product_id) . ' imported (API not fully implemented).</p></div>';
    }
}
?>

<div class="wrap">
    <h2>AliExpress Import</h2>

    <h2 class="nav-tab-wrapper">
        <a href="?page=oopsybuy-product-import-basic&tab=aliexpress&action=import" class="nav-tab <?php echo (!isset($_GET['action']) || $_GET['action'] == 'import') ? 'nav-tab-active' : ''; ?>">Import Product</a>
        <a href="?page=oopsybuy-product-import-basic&tab=aliexpress&action=settings" class="nav-tab <?php echo (isset($_GET['action']) && $_GET['action'] == 'settings') ? 'nav-tab-active' : ''; ?>">Settings</a>
    </h2>

    <?php
    $action = isset($_GET['action']) ? $_GET['action'] : 'import';
    if ($action == 'import') {
        ?>
        <form method="post">
            <label for="aliexpress_product_id">AliExpress Product ID:</label>
            <input type="text" name="aliexpress_product_id" id="aliexpress_product_id" required>
            <input type="submit" name="import_aliexpress_product" class="button button-primary" value="Import">
        </form>
        <?php
    } elseif ($action == 'settings') {
        $api_key = get_option('oopsybuy_aliexpress_api_key');
        ?>
        <form method="post">
            <label for="aliexpress_api_key">AliExpress API Key:</label>
            <input type="text" name="aliexpress_api_key" id="aliexpress_api_key" value="<?php echo esc_attr($api_key); ?>" required>
            <input type="submit" name="save_aliexpress_settings" class="button button-primary" value="Save Settings">
        </form>
        <?php
    }
    ?>
</div>